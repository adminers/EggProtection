package com.rondeo.pixwarsspace;


import java.text.MessageFormat;

/**
 * @Title: TestCon
 * @Description: TestCon
 * @Company: www.qiaweidata.com
 * @author: shenshilong
 * @date: 2024-03-22
 * @version: V1.0
 */
public class TestCon {

    public static void main(String[] args) {


        float w = 32;
        float h = 34;
        int firstX = 10;
        int firstY = 70;
        int heightDifference = 70 - 46;
        int firstXDifference = 26 - 10;

        System.out.println("高度差距:" + heightDifference);

        System.out.println("错位,第一个x差值:" + firstXDifference);

        System.out.println("每个间距(宽度):" + w);

        int colNum = 5;
        int row = 5;

        String str = "'{'\n" +
                "            \"axis\" : '{'\"x\": {0},\"y\": {1}'}',\n" +
                "            \"image\" : \"block_1\"\n" +
                "        '}',";
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < row; i++) {
            int tempX = firstX + firstXDifference * i;
            int tempY = firstY - heightDifference * i;

            // 前面追加

            for (int j = i; j > 0; j--) {
                float v = tempX - w * (j);
                String format = MessageFormat.format(str, v, tempY);
                sb.append(format);
            }
            for (int j = 0; j < colNum; j++) {
                String format = MessageFormat.format(str, tempX + (j * w), tempY);
                sb.append(format);
            }
            sb.append("\n");
        }
        System.out.println(sb);
    }
}

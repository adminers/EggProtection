package com.rondeo.pixwarsspace.gamescreen.components;

import com.badlogic.gdx.scenes.scene2d.Actor;

public interface Entity {
    
    public static class Wrapper extends Actor {
        public long isHit;
    }
}
package com.siondream.freegemas;
//Download by http://www.codefans.net
public class Coord {
	public int x;
	public int y;
	
	public Coord() {
		x = -1;
		y = -1;
	}
	
	public Coord(int x, int y) {
		this.x = x;
		this.y = y;
	}
}

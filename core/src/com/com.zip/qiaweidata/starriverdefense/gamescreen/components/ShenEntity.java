package com.qiaweidata.starriverdefense.gamescreen.components;

import com.badlogic.gdx.scenes.scene2d.Actor;

public interface ShenEntity {
    
    public static class Wrapper extends Actor {
        public long isHit;
    }
}